package ratings.datastructures;

public interface Comparator<T> {
 boolean compare(T a, T b);

}




